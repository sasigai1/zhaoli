import { b as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { C as localIsoDate } from "./_ssr/router-BbYjdJ_G.mjs";
import { t as DayEditor } from "./_ssr/day-editor-G_RXp3Q8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_folio-CR2Gw3OS.js
var import_jsx_runtime = require_jsx_runtime();
function TodayPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DayEditor, { date: localIsoDate() });
}
//#endregion
export { TodayPage as component };
