//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-3Tk5WtBs.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/_folio"],
		preloads: ["/assets/index-BAhkUSDt.js", "/assets/store-LDLxWmY4.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BAhkUSDt.js"
		} }]
	},
	"/_folio": {
		filePath: "/workspace/src/routes/_folio.tsx",
		children: [
			"/_folio/archive",
			"/_folio/metrics",
			"/_folio/",
			"/_folio/d/$date"
		],
		preloads: [
			"/assets/_folio-iz64vXiE.js",
			"/assets/utils-DojpP95n.js",
			"/assets/button-BKB708dl.js"
		]
	},
	"/_folio/archive": {
		filePath: "/workspace/src/routes/_folio/archive.tsx",
		children: void 0,
		preloads: ["/assets/archive-DfNT9CHJ.js", "/assets/field-Cu4iQhip.js"]
	},
	"/_folio/metrics": {
		filePath: "/workspace/src/routes/_folio/metrics.tsx",
		children: void 0,
		preloads: ["/assets/metrics-75SYHelC.js"]
	},
	"/_folio/": {
		filePath: "/workspace/src/routes/_folio/index.tsx",
		children: void 0,
		preloads: ["/assets/_folio-COFSI2gP.js", "/assets/day-editor-D7BRzdHY.js"]
	},
	"/_folio/d/$date": {
		filePath: "/workspace/src/routes/_folio/d.$date.tsx",
		children: void 0,
		preloads: ["/assets/d._date-DZjH07Q5.js", "/assets/day-editor-D7BRzdHY.js"]
	}
} });
//#endregion
export { tsrStartManifest };
