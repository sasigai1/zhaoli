//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DVy_oEr5.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/me",
			"/month",
			"/reminders"
		],
		preloads: ["/assets/index-DCN6HXMw.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DCN6HXMw.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BMFfjcH8.js",
			"/assets/app-shell-DtexMRiC.js",
			"/assets/use-now-WmIMHHvs.js"
		]
	},
	"/me": {
		filePath: "/workspace/src/routes/me.tsx",
		children: void 0,
		preloads: ["/assets/me-B43JVaxx.js", "/assets/app-shell-DtexMRiC.js"]
	},
	"/month": {
		filePath: "/workspace/src/routes/month.tsx",
		children: void 0,
		preloads: [
			"/assets/month-fZLHQO18.js",
			"/assets/app-shell-DtexMRiC.js",
			"/assets/use-now-WmIMHHvs.js"
		]
	},
	"/reminders": {
		filePath: "/workspace/src/routes/reminders.tsx",
		children: void 0,
		preloads: ["/assets/reminders-gDXoBW-q.js", "/assets/app-shell-DtexMRiC.js"]
	}
} });
//#endregion
export { tsrStartManifest };
